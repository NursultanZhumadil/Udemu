package CarShop.com.example.CarShop.controller;

import CarShop.com.example.CarShop.model.Cars;
import CarShop.com.example.CarShop.service.CarService;
import CarShop.com.example.CarShop.service.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;


@Controller
public class CarsController {
    @Autowired
    private CarService carService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping("/add")
    public String showAddCarsForm(Model model) {
        model.addAttribute("car", new Cars());
        model.addAttribute("categories", categoryService.findAllCategories());
        return "add";
    }
    @PostMapping("/add")
    public String addNewCar(@Valid @ModelAttribute("car") Cars car, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("categories", categoryService.findAllCategories());
            return "add";
        }
        carService.saveCar(car);
        model.addAttribute("cars", carService.getAllCars());
        return "redirect:/home";
    }
    @GetMapping("/update/cars/{id}")
    public String showUpdateCarForm(@PathVariable("id") Long id, Model model) {
        Optional<Cars> carOptional = carService.getCarById(id);
        if (carOptional.isEmpty()) {
            return "error";
        }
        Cars car = carOptional.get();
        model.addAttribute("car", car);
        model.addAttribute("categories", categoryService.findAllCategories());
        return "update";
    }

    @PostMapping("/update")
    public String updateCar(@ModelAttribute("car") Cars updatedCar) {
        Optional<Cars> existingCarOptional = carService.getCarById(updatedCar.getId());

        if (existingCarOptional.isEmpty()) {
            return "error";
        }

        Cars existingCar = existingCarOptional.get();

        existingCar.setImg(updatedCar.getImg());
        existingCar.setName(updatedCar.getName());
        existingCar.setModel(updatedCar.getModel());
        existingCar.setYear(updatedCar.getYear());
        existingCar.setAddress(updatedCar.getAddress());
        existingCar.setPrice(updatedCar.getPrice());
        existingCar.setCategories_id(updatedCar.getCategories_id());
        carService.saveCar(existingCar);

        return "redirect:/home";
    }





    @PostMapping("/delete/{id}")
    public String deleteCar(@PathVariable("id") Long id) {
        carService.deleteCar(id);
        return "redirect:/home";
    }

}
