package org.example.udemu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdemuApplication {

    public static void main(String[] args) {
        SpringApplication.run(UdemuApplication.class, args);
    }
}
