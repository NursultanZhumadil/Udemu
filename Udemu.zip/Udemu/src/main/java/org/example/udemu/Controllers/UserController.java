package org.example.udemu.Controllers;

import org.example.udemu.Config.JwtService;
import org.example.udemu.Model.User;
import org.example.udemu.Service.CategoryService;
import org.example.udemu.Service.CourseService;
import org.example.udemu.Service.LanguageService;
import org.example.udemu.Service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private CourseService courseService;
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private LanguageService languageService;
    @Autowired
    private JwtService jwtService;
    @Autowired
    private AuthenticationManager authenticationManager;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute User user, RedirectAttributes redirectAttrs) {
        try {
            userService.registerUser(user);
            redirectAttrs.addFlashAttribute("message", "User registered successfully! Please log in.");
            return "redirect:/users/login";
        } catch (DataIntegrityViolationException e) {
            redirectAttrs.addFlashAttribute("error", "The email or phone number you used has already been registered.");
            return "redirect:/users/register";
        }
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam String email, @RequestParam String password, HttpServletResponse response, RedirectAttributes redirectAttrs) {
        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(email, password));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            String jwt = jwtService.generateToken(userDetails);

            Cookie jwtCookie = new Cookie("JWT_TOKEN", jwt);
            jwtCookie.setHttpOnly(true);
            jwtCookie.setPath("/");
            jwtCookie.setSecure(true);
            response.addCookie(jwtCookie);

//            redirectAttrs.addFlashAttribute("courses", courseService.findAllCourses());
            redirectAttrs.addFlashAttribute("categories", categoryService.findAll());
            redirectAttrs.addFlashAttribute("languages", languageService.findAll());
            return "redirect:/home";
        } catch (AuthenticationException e) {
            return "redirect:/users/login?error=true";
        }
    }


}

