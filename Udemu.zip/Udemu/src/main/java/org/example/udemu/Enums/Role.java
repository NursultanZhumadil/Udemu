package org.example.udemu.Enums;

public enum Role {
    STUDENT,
    ADMIN,
    TEACHER
}
