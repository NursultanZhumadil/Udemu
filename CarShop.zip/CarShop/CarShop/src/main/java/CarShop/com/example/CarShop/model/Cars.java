package CarShop.com.example.CarShop.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cars")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cars {
    private String category;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "categories_id")
    private Long categories_id;
    @Column(name = "name")
    private String name;
    @Column(name = "model")
    private String model;
    @Column(name = "year")
    private int year;
    @Column(name = "img")
    private String img;
    @Column(name = "address")
    private String address;
    @Column(name = "price")
    private String price;

}
