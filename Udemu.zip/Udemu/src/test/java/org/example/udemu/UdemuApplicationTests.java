package org.example.udemu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdemuApplicationTests {

    @Test
    void contextLoads() {
    }

}
