package org.example.udemu.Controllers;

import org.example.udemu.Model.Course;
import org.example.udemu.Service.CategoryService;
import org.example.udemu.Service.CourseService;
import org.example.udemu.Service.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;
    @Autowired
    private LanguageService languageService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public List<Course> getAllCourses() {
        return courseService.getAllCourses();
    }

    @GetMapping("/{id}")
    public Course getCourseById(@PathVariable Long id) {
        return courseService.getCourseById(id);
    }

    @PostMapping
    public Course createCourse(@RequestBody Course course) {
        return courseService.createCourse(course);
    }

    @PutMapping("/{id}")
    public Course updateCourse(@PathVariable Long id, @RequestBody Course course) {
        return courseService.updateCourse(id, course);
    }

    @DeleteMapping("/{id}")
    public void deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
    }
}


//@GetMapping("/create")
//public String showCreateCourseForm(Model model) {
//    Course course = new Course();
//    model.addAttribute("course", course)
//    return "course/create";
//}