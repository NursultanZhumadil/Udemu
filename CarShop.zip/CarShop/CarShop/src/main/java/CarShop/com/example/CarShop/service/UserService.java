package CarShop.com.example.CarShop.service;

import CarShop.com.example.CarShop.model.User;
import CarShop.com.example.CarShop.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) throws Exception {
        try {
            return userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            throw new Exception("Пайдаланушы аты немесе электрондық пошта бұрыннан бар. Басқасын пайдаланыңыз.");
        }
    }

    public User authenticate(String email, String password) {
        User user = userRepository.findByEmail(email);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }
}
