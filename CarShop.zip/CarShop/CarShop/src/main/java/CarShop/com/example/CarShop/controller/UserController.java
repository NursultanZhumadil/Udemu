package CarShop.com.example.CarShop.controller;

import CarShop.com.example.CarShop.model.User;
import CarShop.com.example.CarShop.service.CarService;
import CarShop.com.example.CarShop.service.CategoryService;
import CarShop.com.example.CarShop.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {
    @Autowired
    private CategoryService categoryService;
    @Autowired
    private CarService carService;

    @Autowired
    private UserService userService;

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(User user, Model model) {
        try {
            userService.registerUser(user);
            return "redirect:/login";
        } catch (Exception e) {
            model.addAttribute("error", e.getMessage());
            model.addAttribute("user", user);
            return "register";
        }
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @GetMapping("/home")
    public String home(Model model){
        model.addAttribute("cars", carService.getAllCars());
        model.addAttribute("categories", categoryService.findAllCategories());
        return "home";
    }

    @PostMapping("/login")
    public String loginUser(String email, String password, Model model) {
        User user = userService.authenticate(email, password);
        if (user != null) {
            return "redirect:/home";
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }
    }
}
