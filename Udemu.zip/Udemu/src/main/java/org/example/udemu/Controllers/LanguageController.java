package org.example.udemu.Controllers;

import org.example.udemu.Model.Language;
import org.example.udemu.Service.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/languages")
public class LanguageController {

    @Autowired
    private LanguageService languageService;

    @GetMapping
    public List<Language> getAllLanguages() {
        return languageService.findAll();
    }

    @GetMapping("/{id}")
    public Language getLanguageById(@PathVariable Long id) {
        return languageService.getLanguageById(id);
    }

    @PostMapping
    public Language createLanguage(@RequestBody Language language) {
        return languageService.createLanguage(language);
    }

//    @PutMapping("/{id}")
//    public Language updateLanguage(@PathVariable Long id, @RequestBody Language language) {
//        return languageService.updateLanguage(id, language);
//    }
//
//    @DeleteMapping("/{id}")
//    public void deleteLanguage(@PathVariable Long id) {
//        languageService.deleteLanguage(id);
//    }
}
