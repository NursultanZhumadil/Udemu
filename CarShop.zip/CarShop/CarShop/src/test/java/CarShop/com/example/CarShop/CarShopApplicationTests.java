package CarShop.com.example.CarShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
