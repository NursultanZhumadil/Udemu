package org.example.udemu.Controllers;

import org.example.udemu.Model.Course;
import org.example.udemu.Service.CategoryService;
import org.example.udemu.Service.LanguageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/course")
public class CourseViewController {

    @Autowired
    private LanguageService languageService;
    @Autowired
    private CategoryService categoryService;

    @GetMapping("/create")
    public String showCreateCourseForm(Model model) {
        model.addAttribute("course", new Course());
        model.addAttribute("languages", languageService.findAll());
        model.addAttribute("categories", categoryService.findAll());
        return "course/create";
    }
}
