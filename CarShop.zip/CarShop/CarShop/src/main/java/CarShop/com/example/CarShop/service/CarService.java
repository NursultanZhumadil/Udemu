package CarShop.com.example.CarShop.service;

import CarShop.com.example.CarShop.model.Cars;
import CarShop.com.example.CarShop.repository.CarsRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CarService {

    private CarsRepository carsRepository;

    public CarService(CarsRepository carsRepository) {
        this.carsRepository = carsRepository;
    }

    public List<Cars> getAllCars() {
        return carsRepository.findAll();
    }

    public Optional<Cars> getCarById(Long id) {
        return carsRepository.findById(id);
    }

    public Cars saveCar(Cars car) {
        return carsRepository.save(car);
    }

    public void deleteCar(Long id) {
        carsRepository.deleteById(id);
    }
}
